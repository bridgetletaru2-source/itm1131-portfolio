function celsiusToFahrenheit(celsius) {
    return celsius * 9 / 5 + 32;
}
console.log(celsiusToFahrenheit(0));
console.log(celsiusToFahrenheit(100));
function isEven(number) {return number % 2 === 0;
}
console.log(isEven(4));
console.log(isEven(7));
function greet(name) {return `Hello, ${name}!`;
}
console.log(greet("Ada"));
console.log(greet("Sam"));
const modules =[
    { name: "HTML&CSS" , hours: 12},
    { name: "javascript basics", hours: 8},
    { name: "DOM Manipulation", hours: 14},
    { name: "Git & GitHub", hours: 6},
    { name: "Responsive Design" , hours:11 }
];
console.log(modules)
const isLong = M => M.hours > 10;
const longmodules = modules.filter (isLong);
console. log (longmodules)
longmodules.forEach(m => console.log(`${m.name}: ${m.hours} hours`));
modules.push({ name: "APIs & fetch" , hours: 15});
const longmodulesafter = modules.filter(isLong);
console.log("--- after adding a sixth module---");
longmodulesafter.forEach(m => console.log(`${m.name}: ${m.hours} hours `));
const toggle = document.querySelector('#menu-toggle');
const nav =document.querySelector('#nav');
toggle.addEventListener('click', () => {
    nav.classList.toggle('open');
})
const message = document.querySelector('#message');
const count = document.querySelector('#count');
message.addEventListener('input', () => count.textContent = message.value.length + 'characters')

